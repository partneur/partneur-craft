Submit! Sprout Forms.

Here are some online resources you might find useful:


Sprout Forms Docs
------------------------------------------------------------
Code examples, tags, common questions:
http://sprout.barrelstrengthdesign.com/craft-plugins/forms


Sprout Forms Updates
------------------------------------------------------------
http://sprout.barrelstrengthdesign.com/craft-plugins/forms/updates


Sprout Forms Translations
------------------------------------------------------------
A default translation file is provided on GitHub and can be modified 
as needed for your language requirements.
https://github.com/BarrelStrength/Craft-SproutForms/blob/master/translations/en_us.php


Sprout Forms Support
------------------------------------------------------------

Via Craft Stack Exchange: Tag your questions with `plugin-sproutforms`:
https://craftcms.stackexchange.com/

Via Email:
Send us a note at: sprout@barrelstrengthdesign.com


Sprout Forms License Terms
------------------------------------------------------------
Use of Sprout Forms is subject to the license agreement available here:
http://sprout.barrelstrengthdesign.com/license